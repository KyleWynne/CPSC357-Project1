import UIKit

//: **CPSC-357 Project 1**
//: ** By: Kyle Wynne
//: **Is my number prime**
//:
//: *Resources Used:*
//:
//: Closure info:https://www.geeksforgeeks.org/closures-in-swift/
//: How to check for prime: https://www.wikihow.com/Check-if-a-Number-Is-Prime
//:
//: *Pseudo Code:*
//:
//: isPrime (number)
//:
//: if number == 1
//:
//: return true
//:
//: for i in range number
//:
//:  if i == 1
//:
//:  do nothing
//:
//:  else
//:
//:  r = number % i
//:
//:  if r == 0
//:
//:   return false
//:
//: return true

let isPrime = { (number: Int)->Bool in
    //declare remainder variable
    var r = 0;
    //return true for 0 and 1
    if number == 1 {
        return true;
    }
    //iterate through with the modulo operator to see if we have a division with remainder 0
    for i in 2 ..< number {
        //calculate remainder
        r = number % i;
        //remainder is 0 so number is not prime
        if r == 0 {
            return false;
        }
    }
    //no remainder 0 so number is prime
    return true;
}

let tester1 = 2
let tester2 = 3
let tester3 = 10
let tester4 = 13

print(isPrime(tester1),isPrime(tester2),isPrime(tester3),isPrime(tester4))
