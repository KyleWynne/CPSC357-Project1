import UIKit

//: **Project 1 CPSC-357**
//:
//:  Kyle Wynne
//:
//:  Partial Sum
//:
//:  *Pseudo Code:*
//:
//:  func(dataArray, OperationArray) {
//:
//:  var lowerBound = 0; var UpperBound = 0; var temp; var SolutionArray; var sum;
//:
//:  for i in 0...OperationArray {
//:
//:     temp = OperationArray[i]
//:
//:     lowerbound = temp(0), Upperbound = temp(1)
//:
//:     for i in lowerbound...Upperbound {
//:
//:         sum += dataArray[i]
//:
//:     }
//:
//:     SolutionArray.append(sum)
//:
//:     sum = 0;
//:
//:  }
//:
//:  return SolutionArray
//:
//:  *Resources:*
//:
//:  https://www.programiz.com/swift-programming/tuples

func PartialSum(dataArray: Array<Int>, OperationArray: Array<(Int, Int)>) -> Array<Int> {
    
    var SolutionArray: [Int] = [];
    var sum = 0;
    
    for i in OperationArray {
        sum = 0
        let lowerBound = i.0
        let UpperBound = i.1
        
        for i in lowerBound...UpperBound {
            sum += dataArray[i]
        }
        
        SolutionArray.append(sum)
    }
    return SolutionArray
}

PartialSum(dataArray: [3, 6, 4, 15, 30], OperationArray: [(1,3),(0,4)])
