import UIKit

//: **CPSC-357 Project 1**
//: ** By: Kyle Wynne
//: **Is my email correct**
//:
//: *Resources Used:*
//:
//: none
//:
//: *Pseudo Code:*
//:
//: func checkEmail(string)
//:
//: var check1 = false, var check2 = false
//:
//: for i in len string
//:
//: if !check1: name += i
//:
//: if i == @: check1 = true
//:
//: if i == .: vheck2 = true
//:
//: end loop
//:
//: if check1 && check 2, thank you name
//:
//: else: not an email

func checkEmail(email: String) -> String {
    //variable declarations
    var name = ""
    var check1 = false
    var check2 = false
    
    for i in email {
        print(i)
        if i == "@" {
            check1 = true
            print("hi from check1")
        }
        
        if i == "." {
            check2 = true
            print("hi from check2")
        }
        
        if check1 == false {
            name += String(i)
        }
    }
    
    if check1 && check2  == true {
        return "hanks for the email "+name
    }
    else {
        return "Provide a valid email"
    }
}

checkEmail(email: "cibrian@chapman.edu")
checkEmail(email: "hipjasif@gmail.com")
checkEmail(email: "this is not an email")
checkEmail(email: "cibrien.edu")
