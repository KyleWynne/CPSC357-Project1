import UIKit

//: **CPSC-357 Project 1**
//: ** By: Kyle Wynne
//: **Greatest Common Divisor**
//:
//: *Resources Used:*
//:
//: Asked Chat Gpt the following question: what is the method for finding the greatest common divisor in mathematical terms?
//: Answer
//:
//: Start with two integers, a and b, where a is greater than or equal to b.
//:
//: Divide a by b and find the remainder. Let's denote the remainder as r.
//:
//: Replace a with b and b with r.
//:
//: Repeat steps 2 and 3 until r becomes 0.
//:
//: The GCD is the last non-zero remainder obtained in step 2. In other words, when r becomes 0, the GCD is the value of b at that point.
//:
//: *Pseudo Code:*
//:
//: function GCD (int a, int b), a = b, b=temp
//:
//: if a>b then a % b = temp
//:
//: else b % a = temp, b = temp
//:
//: if r = 0, return a
//:

func GCD( a: Int,  b: Int) -> Int {
    //assign a and b based off which is greater for b to always be what is returned
    var a1 = 0
    var b1 = 0
    var r = 0;
    //assignments for a > b
    if a > b {
        a1 = a
        b1 = b
    }
    //assignmnets for a < b
    else {
        a1 = b
        b1 = a
    }
    
    //iterate with a while loop finsing the remainder and dividing till it finds the greatest common divisor
    while true {
        r = a1 % b1
        a1 = b1
        b1 = r
        if r == 0{
            break
        }
    }
    //return the gcd
    return a1
}

//testing code
let c1 = 9
let c2 = 3
//output
print("The gcd is", GCD(a: c1, b: c2))

